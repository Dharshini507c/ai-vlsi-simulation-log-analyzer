import unittest
from analyzer import analyze_log


class TestAnalyzeLog(unittest.TestCase):
    def test_counts_errors_warnings_passes_and_failures(self):
        log = """[PASS] reset_test
[WARNING] timing note
[ERROR] mismatch
[FAIL] alu_test"""
        result = analyze_log(log)
        self.assertEqual(len(result["errors"]), 1)
        self.assertEqual(len(result["warnings"]), 1)
        self.assertEqual(len(result["passes"]), 1)
        self.assertEqual(len(result["failures"]), 1)
        self.assertEqual(result["total_lines"], 4)

    def test_empty_log(self):
        result = analyze_log("")
        self.assertEqual(result["total_lines"], 0)
        self.assertEqual(result["errors"], [])
        self.assertEqual(result["warnings"], [])


if __name__ == "__main__":
    unittest.main()
