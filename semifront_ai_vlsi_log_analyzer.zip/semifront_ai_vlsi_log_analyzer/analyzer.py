"""
AI-ready VLSI Simulation Log Analyzer
A beginner-friendly Python project that scans simulation logs for errors,
warnings, and failed tests, then generates a text report.

This starter version works offline and does not require an AI API key.
"""

from pathlib import Path
import argparse
import re
from datetime import datetime

ERROR_PATTERNS = [
    re.compile(r"\bERROR\b", re.IGNORECASE),
    re.compile(r"\bFATAL\b", re.IGNORECASE),
]
WARNING_PATTERN = re.compile(r"\bWARN(?:ING)?\b", re.IGNORECASE)
PASS_PATTERN = re.compile(r"\bPASS(?:ED)?\b", re.IGNORECASE)


def analyze_log(log_text: str) -> dict:
    """Return counts and matching lines from a simulation log."""
    lines = log_text.splitlines()
    errors = []
    warnings = []
    passes = []
    failures = []

    for line_number, line in enumerate(lines, start=1):
        if any(pattern.search(line) for pattern in ERROR_PATTERNS):
            errors.append((line_number, line.strip()))
        if WARNING_PATTERN.search(line):
            warnings.append((line_number, line.strip()))
        if PASS_PATTERN.search(line):
            passes.append((line_number, line.strip()))
        if re.search(r"\bFAIL(?:ED|URE)?\b", line, re.IGNORECASE):
            failures.append((line_number, line.strip()))

    return {
        "total_lines": len(lines),
        "errors": errors,
        "warnings": warnings,
        "passes": passes,
        "failures": failures,
    }


def format_report(result: dict, source_name: str) -> str:
    """Format analysis results into a readable report."""
    status = "REVIEW NEEDED" if result["errors"] or result["failures"] else "NO ERROR/FAILURE KEYWORDS FOUND"
    output = [
        "=" * 64,
        "VLSI SIMULATION LOG ANALYSIS REPORT",
        "=" * 64,
        f"Source file : {source_name}",
        f"Generated   : {datetime.now().astimezone().isoformat(timespec='seconds')}",
        f"Total lines : {result['total_lines']}",
        f"Errors      : {len(result['errors'])}",
        f"Warnings    : {len(result['warnings'])}",
        f"Pass lines  : {len(result['passes'])}",
        f"Fail lines  : {len(result['failures'])}",
        f"Overall     : {status}",
        "",
        "NOTE: Keyword matches are only clues. Review the original log; this tool",
        "does not prove the root cause of a hardware or simulation failure.",
    ]

    sections = [
        ("ERROR / FATAL MATCHES", result["errors"]),
        ("WARNING MATCHES", result["warnings"]),
        ("PASS MATCHES", result["passes"]),
        ("FAIL MATCHES", result["failures"]),
    ]
    for title, matches in sections:
        output.extend(["", f"--- {title} ---"])
        if not matches:
            output.append("None found.")
        else:
            for line_number, line in matches:
                output.append(f"Line {line_number}: {line}")

    return "\n".join(output) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Scan a VLSI/RTL simulation log and create a summary report."
    )
    parser.add_argument(
        "logfile",
        nargs="?",
        default="sample_logs/sample_simulation.log",
        help="Path to the text log file (default: sample_logs/sample_simulation.log)",
    )
    parser.add_argument(
        "-o", "--output",
        default="reports/analysis_report.txt",
        help="Output report path (default: reports/analysis_report.txt)",
    )
    args = parser.parse_args()

    log_path = Path(args.logfile)
    if not log_path.is_file():
        parser.error(f"Log file not found: {log_path}")

    text = log_path.read_text(encoding="utf-8", errors="replace")
    result = analyze_log(text)
    report = format_report(result, log_path.name)

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(report, encoding="utf-8")

    print(f"Analysis complete: {log_path}")
    print(f"Lines scanned: {result['total_lines']}")
    print(f"Errors: {len(result['errors'])} | Warnings: {len(result['warnings'])} | "
          f"Passes: {len(result['passes'])} | Failures: {len(result['failures'])}")
    print(f"Report saved to: {output_path}")


if __name__ == "__main__":
    main()
