# AI-Ready VLSI Simulation Log Analyzer

A beginner-friendly Python project that scans RTL/VLSI simulation log files and creates a readable report of error, fatal, warning, pass, and fail messages.

This is an **offline starter version**: it uses Python's standard library and does not need an API key. It is designed as a first step toward AI-assisted verification support tools.

## Why this project?

RTL and verification engineers often inspect simulation output to find failed tests and error messages. This tool automates the first-pass sorting of log messages so an engineer can review the relevant lines more quickly.

## Features

- Reads a plain-text simulation log.
- Detects lines containing `ERROR`, `FATAL`, `WARNING`, `PASS`, and `FAIL` keywords.
- Reports the line number and original text for each match.
- Counts total lines and matching messages.
- Saves a report to a text file.
- Includes sample input and unit tests.
- Uses only the Python standard library.

> Important: this tool performs keyword matching. It does not understand RTL semantics and does not prove the root cause of a failure. Always inspect the original log.

## Requirements

- Python 3.9 or newer recommended.
- No third-party packages needed.

## Run it

From the project folder:

```bash
python analyzer.py
```

This uses `sample_logs/sample_simulation.log` and writes the report to `reports/analysis_report.txt`.

To analyze another log file:

```bash
python analyzer.py path/to/your_simulation.log -o reports/my_report.txt
```

## Run the tests

```bash
python -m unittest discover -s tests -v
```

## Example sample log

```text
[INFO] Starting RTL simulation: alu_test
[PASS] reset_test completed successfully
[WARNING] Operand overflow observed in add_test
[ERROR] Expected result 0x03, got 0x02
[FAIL] subtract_test failed
```

## Example output

```text
VLSI SIMULATION LOG ANALYSIS REPORT
Total lines : 9
Errors      : 2
Warnings    : 1
Pass lines  : 2
Fail lines  : 1
Overall     : REVIEW NEEDED
```

Counts depend on the exact sample file. A line containing `FATAL` is counted as an error match; `FAIL` messages are counted separately.

## Project structure

```text
ai-ready-vlsi-log-analyzer/
├── analyzer.py
├── sample_logs/
│   └── sample_simulation.log
├── tests/
│   └── test_analyzer.py
├── reports/
│   └── .gitkeep
├── requirements.txt
└── README.md
```

## Next improvements

1. Add support for simulator-specific log formats.
2. Export reports as CSV or JSON.
3. Add an optional LLM API integration to explain selected log messages.
4. Compare regression runs and highlight newly failing tests.
5. Add a small command-line option to filter by test name.

## Skills demonstrated

Python, regular expressions, file handling, command-line arguments, testing, and a semiconductor verification use case.
